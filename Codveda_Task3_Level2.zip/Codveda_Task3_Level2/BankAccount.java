

public class BankAccount implements Operation
{
   private double balance;
   
   public BankAccount(double initialAmount){
       this.balance = Math.max(0, initialAmount);
   }
   
   @Override
   public void deposit(double amount){
       if(amount > 0){
           balance += amount;
       }
   }
   
   @Override
   public void withdraw(double amount){
       if(amount > 0 && amount <= balance){
           balance -= amount;
       }
   }
   
   @Override
   public double getBalance(){
       return balance;
   }
}
