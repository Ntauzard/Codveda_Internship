

public interface Operation
{
    void deposit(double amaount);
    void withdraw(double amount);
    double getBalance();
}
