import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class BankGUI
{
    public static void main(String[] args){
        Operation account = new BankAccount(0);
        
        JFrame frame = new JFrame("Simple Banking System");
        frame.setSize(350, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(5, 1, 5, 5));
        
        JTextField amountField = new JTextField();
        JLabel balanceLabel = new JLabel();
        
        JButton btnDeposit = new JButton("Deposit");
        JButton btnWithdraw = new JButton("Withdraw");
        JButton btnBalance = new JButton("Check Balance");
        
        frame.add(new JLabel("Enter Amount: ",SwingConstants.CENTER));
        frame.add(amountField);
        frame.add(balanceLabel);
        frame.add(btnDeposit);
        frame.add(btnWithdraw);
        frame.add(btnBalance);
        
        btnDeposit.addActionListener(e -> {
           try{
               double amount = Double.parseDouble(amountField.getText());
               account.deposit(amount);
               
               amountField.setText("");
           
           }catch(NumberFormatException ex){
               JOptionPane.showMessageDialog(frame, "Invalid amount!");
           }
        });
        
        btnWithdraw.addActionListener(e -> {
           try{
               double amount = Double.parseDouble(amountField.getText());
               
               if(amount > account.getBalance()){
                   JOptionPane.showMessageDialog(frame,"Insufficient Funds!!");
               }
               else{
                   account.withdraw(amount);
                   
                   
               }
               amountField.setText("");
           }catch(NumberFormatException ex){
               JOptionPane.showMessageDialog(frame, "Invalid amount!");
           }
        });
        
        btnBalance.addActionListener(e -> 
           balanceLabel.setText("Balance: R" + account.getBalance())
        );
        
        frame.setVisible(true);
    }
}











