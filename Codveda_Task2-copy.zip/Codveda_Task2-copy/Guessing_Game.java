
import java.util.*;
public class Guessing_Game
{
    public static void main(String[] args){
       Random random = new Random();
       Scanner sc = new Scanner(System.in);
       
       
       char replay = 'y';
       
       while(replay == 'y' || replay == 'Y'){
           int maxAttempts = 5;
           int attempts = 0;
           boolean guessed = false;
           int randNum = random.nextInt(100)+1;
           System.out.println("Welcome to the Guessing Game!");
           System.out.println("You have "+ maxAttempts + " attempts to guess the correct number!");
           while(attempts < maxAttempts || guessed){
               System.out.println("Enter your number: ");
           
           
               if(!sc.hasNextInt()){
                   System.out.println("Invalid! - Enter a number: ");
                   sc.next();
                   continue;
               }
           
               int n = sc.nextInt();
               if(n < 1 || n > 100){
                   System.out.println("Invalid - Enter a number between 1 - 100");
               }
               else if(n > randNum){
                   System.out.println("Too high");
               }
               else if(n < randNum){
                   System.out.println("Too low");
               }
               else{
                   guessed = true;
                   System.out.println("That is a correct guess!: " + n);
                   break;
               }
               attempts++;
           }
           System.out.println("You have used all your attempts!");
           System.out.println("The correct guess is: " + randNum);
           
           System.out.println("Do you want to play again? (y/n): ");
           replay = sc.next().charAt(0);
       }
       System.out.println("Goodbye!");
       
       sc.close();
    }
}
