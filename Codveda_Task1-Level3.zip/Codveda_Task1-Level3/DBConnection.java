import java.sql.*;

public class DBConnection
{
   private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
   private static final String USER = "hr";
   private static final String PASSWORD = "cmpg311";
   
   public static Connection getConnection() throws Exception{
       Class.forName("oracle.jdbc.OracleDriver");
       return DriverManager.getConnection(URL, USER, PASSWORD);
   }
   
   public void addBook(String title, String author) throws Exception{
       String sql = "INSERT INTO books (title, author, available) VALUES (?, ?, 1)";
       
       try(Connection con = DBConnection.getConnection();
           PreparedStatement ps = con.prepareStatement(sql)){
               
               ps.setString(1, title);
               ps.setString(2, author);
               ps.executeUpdate();
           }
   }
   
   public void viewBooks() throws Exception{
       String sql = "SELECT * FROM books";
       
       Connection con = getConnection();
       Statement st = con.createStatement();
       ResultSet rs = st.executeQuery(sql);
       
       while(rs.next()){
           System.out.println(rs.getInt("book_id") + " | " +
                              rs.getString("title") + " | " +
                              rs.getString("author") + " | Available: " +
                              rs.getInt("available") 
           );
       }
   }
   
   public void borrowBook(int bookId, int userId) throws Exception{
       Connection con = getConnection();
       con.setAutoCommit(false);
       
       try{
           String check = "SELECT available FROM books WHERE book_id =?";
           PreparedStatement psCheck = con.prepareStatement(check);
           psCheck.setInt(1, bookId);
           ResultSet rs = psCheck.executeQuery();
           
           if(rs.next() && rs.getInt("available") == 1){
               
               String update = "UPDATE books SET available=0 WHERE book_id=?";
               PreparedStatement ps1  = con.prepareStatement(update);
               ps1.setInt(1, bookId);
               ps1.executeUpdate();
               
               String insert = "INSERT INTO transactions (book_id, user_id) VALUES (?, ?)";
               PreparedStatement ps2 = con.prepareStatement(insert);
               ps2.setInt(1, bookId);
               ps2.setInt(2, userId);
               ps2.executeUpdate();
               
               con.commit();
               System.out.println("Book borrowed successfully.");
           }
           else{
               System.out.println("Book not available.");
           }
           
       }catch (Exception e){
           con.rollback();
           e.printStackTrace();
       }finally {
           con.setAutoCommit(true);
           con.close();
       }
   }
   
   public void returnBook(int bookId) throws Exception{
       Connection con = getConnection();
       con.setAutoCommit(false);
       
       try{
           String updateBook = "UPDATE books SET available=1 WHERE book_id=?";
           PreparedStatement ps1 = con.prepareStatement(updateBook);
           ps1.setInt(1, bookId);
           ps1.executeUpdate();
           
           String updateTransaction = "UPDATE transactions SET return_date=SYSTIMESTAMP WHERE book_id=? AND return_date IS NULL";
           PreparedStatement ps2 = con.prepareStatement(updateTransaction);
           ps2.setInt(1, bookId);
           ps2.executeUpdate();
           
           con.commit();
           System.out.println("Book returned successfully");
           
       }catch (Exception e) {
           con.rollback();
           e.printStackTrace();
       }finally {
           con.setAutoCommit(true);
           con.close();
       }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
   }
}
