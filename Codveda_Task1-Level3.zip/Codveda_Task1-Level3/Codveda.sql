CREATE TABLE books(
   book_id NUMBER PRIMARY KEY,
   title VARCHAR2(100) NOT NULL,
   author VARCHAR2(100) NOT NULL,
   available NUMBER(1) DEFAULT 1
);

CREATE TABLE tblUsers(
   user_id NUMBER PRIMARY KEY,
   user_name VARCHAR2(100) NOT NULL
);

CREATE TABLE transactions(
   transaction_id NUMBER PRIMARY KEY,
   book_id NUMBER,
   user_id NUMBER,
   borrow_date TIMESTAMP DEFAULT SYSTIMESTAMP,
   return_date TIMESTAMP,
   CONSTRAINT fk_book FOREIGN KEY (book_id) REFERENCES books(book_id),
   CONSTRAINT fk_users FOREIGN KEY (user_id) REFERENCES tblUsers(user_id)
);

CREATE SEQUENCE book_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE users_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE transaction_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER book_trigger
BEFORE INSERT ON books
FOR EACH ROW
BEGIN
   :NEW.book_id := book_seq.NEXTVAL;
END;
/

CREATE OR REPLACE TRIGGER users_trigger
BEFORE INSERT ON tblUsers
FOR EACH ROW
BEGIN
   :NEW.user_id := users_seq.NEXTVAL;
END;
/

CREATE OR REPLACE TRIGGER transaction_trigger
BEFORE INSERT ON transactions
FOR EACH ROW
BEGIN
   :NEW.transaction_id := transaction_seq.NEXTVAL;
END;
/

INSERT INTO books (title, author, available) VALUES ('Clean Code', 'Robert C. Martin', 1);
INSERT INTO books (title, author, available) VALUES ('Effective Java', 'Joshua Bloch', 1);
INSERT INTO books (title, author, available) VALUES ('The Mother', 'Jennifer Lopez', 1);
INSERT INTO books (title, author, available) VALUES ('Welcome To Derry', 'Pennywise', 1);


INSERT INTO tblUsers (user_name) VALUES ('Ntau Temane');
INSERT INTO tblUsers (user_name) VALUES ('John Doe');
INSERT INTO tblUsers (user_name) VALUES ('Bofelo Temane');
INSERT INTO tblUsers (user_name) VALUES ('Pulane Tomotomo');

COMMIT;














