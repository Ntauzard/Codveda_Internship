import java.sql.*;
import java.util.*;

public class TestClass
{
    public static void main(String[] args) throws Exception{
        DBConnection db = new DBConnection();
        Scanner sc = new Scanner(System.in);
        
        char con = 'y';
        while(con == 'y' || con == 'Y'){
            System.out.println("1.Add a book?");
            System.out.println("2.View books?");
            System.out.println("3.Borrow a book?");
            System.out.println("4.Return a book?");
            System.out.println("5.Exit?");
            System.out.println("What would you like to do?(1/2/3/4/5):");
            
            
            int operation = sc.nextInt();
            
            switch(operation) {
                case 1:
                    System.out.println("Book name: ");
                    String book = sc.next();
                    System.out.println("Author name: ");
                    String author = sc.next();
                    db.addBook(book, author);
                    System.out.println("Book added successfully!");
                    break;
                case 2:
                    db.viewBooks();
                    break;
                case 3:
                    System.out.println("Book Id: ");
                    int bookId = sc.nextInt();
                    System.out.println("User Id: ");
                    int userId = sc.nextInt();
                    db.borrowBook(bookId, userId);
                    break;
                case 4:
                    System.out.println("Book Id: ");
                    bookId = sc.nextInt();
                    db.returnBook(bookId);
                    break;
                default:
                    break;
            }
            System.out.println("Would you like to continue?(y/n): ");
            con = sc.next().charAt(0);

        }
    }
}
