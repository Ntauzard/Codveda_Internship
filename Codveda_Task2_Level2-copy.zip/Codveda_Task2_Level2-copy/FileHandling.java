import java.util.*;
import java.io.*;

public class FileHandling
{
    public static void main(String[] args){
        int lineCount = 0;
        int wordCount = 0;
        int charCount = 0;
        
        try{
            File file = new File("words.txt");
            Scanner sc = new Scanner(file);
            FileWriter writer = new FileWriter("output.txt");
            
            while(sc.hasNextLine()){
                lineCount++;
                
                String line = sc.nextLine();
                charCount += line.length();
                if(!line.trim().isEmpty()){
                    String[] words = line.trim().split(" ");
                    wordCount += words.length;
                }
            }
            System.out.println("File read successfully!");
            
            writer.write("------Processed results!-------");
            writer.write("Line Count: " + lineCount + "\n");
            writer.write("Word Count: " + wordCount + "\n");
            writer.write("Character Count: " + charCount);
            
            sc.close();
            writer.close();
            
            System.out.println("File written  successfully!");
        }catch (FileNotFoundException e){
            System.out.println("File not found");
        }catch (IOException e){
            System.out.println("Error writing the file");
        }
    }
}
