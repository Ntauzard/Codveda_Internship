import java.util.*;
public class Recursion
{
    public static long factorial(int n){
        if(n < 0){
            throw new IllegalArgumentException("Factorial is not defined for negative numbers!");
        }
         
        if(n == 0){
            return 1;
        }
        else{
            return n * factorial(n-1);
        }
    }
    
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        while(choice == 'y' || choice == 'Y'){
            System.out.println("Enter your number: ");
        
            if(!sc.hasNextInt()){
                System.out.println("Invalid! - Enter a number: ");
                sc.next();
                continue;
            }
            else{
                int number = sc.nextInt();
                
                try{
                    long result = factorial(number);
                    System.out.println("Factorial of " +number +" is "+ result);
            
                    System.out.println("Would you like to factorise again? (y/n): ");
                    choice = sc.next().charAt(0);
                }catch (IllegalArgumentException e){
                    System.out.println(e.getMessage());
                }
                
            }
            
        }
        System.out.println("Done!");
        sc.close();
    }
}


