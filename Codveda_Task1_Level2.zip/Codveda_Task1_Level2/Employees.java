

public class Employees
{
    private String  name;
    private int id;
    private double salary;
    
    public Employees(int id, String name, double salary){
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    
    public int getID(){
        return id;
    }
    
    public String getName(){
        return name;
    }
    
    public double getSalary(){
        return salary;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public void setSalary(double salary){
        this.salary = salary;
    }
    
    @Override
    public String toString(){
        return "ID: "+id+"\nName: "+name+"\nSalary: "+salary;
    }
}
