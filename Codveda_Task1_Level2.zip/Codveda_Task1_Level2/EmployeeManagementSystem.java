import java.util.*;
public class EmployeeManagementSystem 
{
    private static ArrayList<Employees> employees = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);
    
    public static void addEmployee(){
        System.out.println("Enter the id: ");
        int id = sc.nextInt();
        
        System.out.println("Enter the name: ");
        String name = sc.next();
        
        System.out.println("Enter the salary: ");
        double salary = sc.nextDouble();
        
        employees.add(new Employees(id, name, salary));
        System.out.println("Employee added succesfully");
    }
    
    public static void viewEmployees(){
        if(employees.isEmpty()){
            System.out.println("No employees found");
        }
        
        for(Employees emp : employees){
            System.out.println(emp);
        }
    }
    
    public static void updateEmployees(){
        System.out.println("Enter the id to update: ");
        int id = sc.nextInt();
        
        for(Employees emp : employees){
            if(emp.getID() == id){
                sc.nextLine();
                System.out.println("Enter new name: ");
                emp.setName(sc.nextLine());
                
                System.out.println("Enter new salary: ");
                emp.setSalary(sc.nextDouble());
                
                System.out.println("Employee updated successfully!");
            }
            
        }
        
    }
    
    public static void deleteEmployees(){
        System.out.println("Enter employee id to delete: ");
        int id = sc.nextInt();
        
        for(Employees emp : employees){
            if(emp.getID() == id){
                employees.remove(emp);
                System.out.println("Employee deleted successfully");
            }
            
        }
        
    }
    
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        
        System.out.println("====Employee Management System====");
        System.out.println("1. Add employees");
        System.out.println("2. View employees");
        System.out.println("3. Update emplyees");
        System.out.println("4. Delete employees");
        System.out.println("5. Exit");
        while(choice != 5){
            
        
            System.out.println("Choose operation(1/2/3/4/5): ");
            choice = sc.nextInt();
            
            switch(choice){
                case 1: 
                    addEmployee();
                    break;
                case 2:
                    viewEmployees();
                    break;
                case 3:
                    updateEmployees();
                    break;
                case 4:
                    deleteEmployees();
                    break;
                case 5:
                    System.out.println("Exiting.......");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
        
        
    }
}
