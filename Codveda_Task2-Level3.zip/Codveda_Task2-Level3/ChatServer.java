import java.io.*;
import java.util.*;
import java.net.*;
import java.util.HashSet;

public class ChatServer
{
    private static final int PORT = 1234;
    private static Set<ClientHandler> clients = new HashSet<>();
    
    public static void main(String[] args){
        System.out.println("Server started....");
        
        try(ServerSocket serverSocket = new ServerSocket(PORT)){
            while(true){
                Socket socket = serverSocket.accept();
                System.out.println("Client connected");
                
                ClientHandler handler = new ClientHandler(socket);
                clients.add(handler);
                handler.start();
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    
    public static void broadcast(String message, ClientHandler sender){
        for(ClientHandler client : clients){
            if(client != sender){
                client.sendMessage(message);
            }
        }
    }
    
    public static void removeClient(ClientHandler client){
        clients.remove(client);
        System.out.println("Client disconnected");
    }
}
