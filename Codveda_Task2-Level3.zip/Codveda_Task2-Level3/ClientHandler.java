import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ClientHandler extends Thread
{
    private Socket socket;
    private PrintWriter out;
    private Scanner in;
    private String username;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try {
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);

            out.println("Welcome to the chat!");

            while (in.hasNextLine()) {
                String message = in.nextLine();
                System.out.println("Received: " + message);
                ChatServer.broadcast(message, this);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ChatServer.removeClient(this);
        }
    }

    public void sendMessage(String message) {
        out.println(message);
    }
}
