
import java.net.*;
import java.io.*;
import java.util.Scanner;

public class ChatClient
{
    private static final String SERVER = "localhost";
    private static final int PORT = 1234;

    public static void main(String[] args) {

        try {
            Socket socket = new Socket(SERVER, PORT);

            Scanner serverIn = new Scanner(socket.getInputStream());
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            Scanner userInput = new Scanner(System.in);

            // Thread for receiving messages
            Thread receiveThread = new Thread(new Runnable() {
                public void run(){
                    while (serverIn.hasNextLine()) {
                        System.out.println(serverIn.nextLine());
                    }

                }
                
            });

            receiveThread.start();

            // Send user messages
            while (userInput.hasNextLine()) {
                out.println(userInput.nextLine());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
