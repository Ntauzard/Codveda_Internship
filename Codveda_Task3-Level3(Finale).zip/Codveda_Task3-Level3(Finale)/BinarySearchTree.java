

public class BinarySearchTree
{
    private TreeNode root;
    
    public BinarySearchTree(){
        root = null;
    }
    
    public void insert(int data){
        root = insertNode(root, data);
    }
    
    private TreeNode insertNode(TreeNode root, int data){
        if(root == null){
            return new TreeNode(data);
        }
        
        if(data < root.data){
            root.left = insertNode(root.left, data);
        }
        else if(data > root.data){
            root.right = insertNode(root.right, data);
        }
        
        return root;
    }
    
    public boolean search(int data){
        return searchNode(root, data);
    }
    
    private boolean searchNode(TreeNode root, int data){
        if(root == null){
            return false;
        }
        
        if(root.data == data){
            return true;
        }
        
        return data < root.data ? searchNode(root.left, data) : searchNode(root.right, data);
    }
    
    public void delete(int data){
        root = deleteNode(root, data);
    }
    
    private TreeNode deleteNode(TreeNode root, int data){
        if(root == null){
            return null;
        }
        
        if(data < root.data){
            root.left = deleteNode(root.left, data);
        }
        else if(data > root.data){
            root.right = deleteNode(root.right, data);
        }
        else{
            if(root.left == null) return root.right;
            if(root.left == null) return root.left;
            
            root.data = minValue(root.right);
            root.right = deleteNode(root.right, root.data);
        }
        return root;
    }
    
    private int minValue(TreeNode root){
        int min = root.data;
        while(root.left != null){
            min = root.left.data;
            root = root.left;
        }
        return min;
    }
    
    public void inorder(){
        inorderTrav(root);
        System.out.println();
    }
    
    private void inorderTrav(TreeNode root){
        if(root != null){
            inorderTrav(root.left);
            System.out.println(root.data + " ");
            inorderTrav(root.right);
        }
    }
    
    public void preorder(){
        preorderTrav(root);
        System.out.println();
    }
    
    private void preorderTrav(TreeNode root){
        if(root != null){
            System.out.println(root.data + " ");
            preorderTrav(root.left);
            preorderTrav(root.right);
        }
    }
    
    public void postorder(){
        postorderTrav(root);
        System.out.println();
    }
    
    private void postorderTrav(TreeNode root){
        if(root != null){
            postorderTrav(root.left);
            postorderTrav(root.right);
            System.out.println(root.data + " ");
        }
    }
}
