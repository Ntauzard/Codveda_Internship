

public class TestClass
{
    public static void main(String[] args){
        System.out.println("Inserting data....");
        
        BinarySearchTree tree = new BinarySearchTree();
        
        tree.insert(50);
        tree.insert(30);
        tree.insert(70);
        tree.insert(20);
        tree.insert(40);
        tree.insert(60);
        tree.insert(80);
        
        System.out.println("In-order traversal:");
        tree.inorder();
        
        System.out.println("Pre-order traversal:");
        tree.preorder();
        
        System.out.println("Post-order traversal:");
        tree.postorder();
        
        tree.search(20);
        
        tree.delete(20);
    }
}
