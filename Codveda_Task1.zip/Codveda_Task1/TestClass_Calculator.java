import java.util.*;

public class TestClass_Calculator extends Basic_Calculator
{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
        char choice = 'y';
        while(choice == 'y' || choice == 'Y'){
            System.out.println("Enter the first number: ");
            double num1 = sc.nextDouble();
        
            System.out.println("Enter the second number: ");
            double num2 = sc.nextDouble();
        
            System.out.println("Choose operation: ");
            System.out.println("+ : Addition");
            System.out.println("- : Subtraction");
            System.out.println("* : Multiplication");
            System.out.println("/ : Division");
        
            System.out.println("Enter an operation: ");
            char operation = sc.next().charAt(0);
        
            double result;
            switch(operation){
                case '+':
                    result = add(num1, num2);
                    break;
                case '-':
                    result = subtract(num1, num2);
                    break;  
                case '*':
                    result = multiply(num1, num2);
                    break;     
                case '/':
                    result = divide(num1, num2);
                    break;    
                default:
                    System.out.println("Invalid input!!");
                    continue;
            }
            System.out.println("Result: " + result);
            
            System.out.println("Do you want to perform another operation?(y/n): ");
            choice = sc.next().charAt(0);
        }
        System.out.println("Calculator closed!");
        sc.close();
    }
}
